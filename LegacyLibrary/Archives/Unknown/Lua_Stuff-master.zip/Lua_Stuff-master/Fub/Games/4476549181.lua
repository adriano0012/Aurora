--[[
    Pet ranch simulator
]]